# Villa Alang Kayu — Website Booking Villa Luxury Canggu

Website belajar untuk implementasi **GTM → GA4 → Looker Studio → SEO** pada studi kasus booking villa di Canggu, Bali.

## 🌐 Live Demo
Setelah GitHub Pages aktif, situs akan tersedia di:
`https://<username-kamu>.github.io/<nama-repo>/`

## 📁 Struktur File
```
├── index.html         # Website utama (GTM snippet + tracking + SEO meta)
├── robots.txt          # Instruksi crawling untuk Google
├── sitemap.xml          # Daftar halaman untuk Google index
└── PANDUAN-SETUP.md     # Panduan lengkap setup GTM/GA4/Looker Studio/SEO
```

## 🚀 Cara Deploy via GitHub Pages
1. Push semua file ini ke repo GitHub (lihat instruksi di bawah)
2. Buka repo → **Settings** → **Pages**
3. Source: pilih branch `main`, folder `/ (root)`
4. Save → tunggu 1-2 menit → situs live di URL yang muncul di atas

## 🔧 Yang Wajib Diganti Sebelum Go-Live
- [ ] `GTM-XXXXXXX` di `index.html` (2 lokasi: `<head>` dan `<body>`) → Container ID GTM asli
- [ ] URL `villaalangkayu.com` di meta tag, schema.org, `robots.txt`, `sitemap.xml` → domain/URL GitHub Pages kamu
- [ ] Nomor telepon, email, alamat di footer
- [ ] Foto Unsplash placeholder → foto villa asli

## 📖 Panduan Lengkap
Baca `PANDUAN-SETUP.md` untuk step-by-step menghubungkan:
1. Google Tag Manager
2. Google Analytics 4
3. Looker Studio Dashboard
4. SEO checklist

## 📝 Lisensi
Dibuat untuk keperluan belajar. Bebas dimodifikasi.
