# Panduan Setup: Website → GTM → GA4 → Looker Studio → SEO

Panduan ini untuk belajar alur analytics dari nol. Ikuti urutannya, jangan loncat.

---

## 1. Struktur File

```
villa-canggu/
├── index.html        ← website utama (sudah ada GTM snippet + tracking)
├── robots.txt         ← izin crawling untuk Google
├── sitemap.xml         ← daftar halaman untuk Google index
└── PANDUAN-SETUP.md    ← file ini
```

---

## 2. Setup Google Tag Manager (GTM)

**Kenapa GTM dulu, bukan langsung GA4?**
GTM itu "pengatur lalu lintas" — semua tag (GA4, Facebook Pixel, dll) dipasang lewat GTM, jadi kamu tidak perlu edit kode HTML tiap kali mau nambah tracking baru.

### Langkah:
1. Buka [tagmanager.google.com](https://tagmanager.google.com), buat akun baru.
2. Buat **Container** baru → pilih target "Web" → catat **Container ID** (formatnya `GTM-XXXXXXX`).
3. Di file `index.html`, cari 2 tempat yang ada tulisan `GTM-XXXXXXX` dan ganti dengan Container ID kamu:
   - Satu di `<head>` (script utama)
   - Satu di `<body>` (noscript iframe)
4. Publish container setelah selesai konfigurasi tag (langkah 3 di bawah).

### Konsep dataLayer (sudah ada di kode)
Website ini sudah push event ke `dataLayer` di beberapa titik:

| Event Name | Kapan Terjadi | Parameter |
|---|---|---|
| `cta_click` | Klik tombol "Booking Sekarang" / "Pilih Kamar Ini" | `click_label` |
| `generate_lead` | Form booking berhasil disubmit | `checkin_date`, `checkout_date`, `room_type`, `guest_count` |
| `scroll_50_percent` | User scroll lewat 50% halaman | - |

Ini bisa dicek langsung: buka website → tekan **F12** → tab **Console** → coba klik tombol atau isi form. Kamu akan lihat log `dataLayer push: ...`.

---

## 3. Menghubungkan GTM ke GA4

### A. Buat properti GA4 dulu
1. Buka [analytics.google.com](https://analytics.google.com) → Admin → **Create Property**.
2. Isi nama properti (misal "Villa Alang Kayu"), zona waktu Indonesia, mata uang IDR.
3. Setelah properti dibuat, buka **Data Streams** → **Add stream** → **Web**.
4. Masukkan URL website kamu → catat **Measurement ID** (formatnya `G-XXXXXXXXXX`).

### B. Buat tag GA4 di dalam GTM
1. Di GTM, buka tab **Tags** → **New**.
2. Pilih tipe tag **Google Analytics: GA4 Configuration**.
3. Masukkan Measurement ID (`G-XXXXXXXXXX`) dari langkah A.
4. Trigger: pilih **All Pages** (supaya GA4 aktif di semua halaman).
5. Simpan tag ini dengan nama `GA4 - Config`.

### C. Buat tag untuk event custom
Untuk setiap event di dataLayer, buat tag terpisah:

**Contoh: Event `generate_lead` (booking form submit)**
1. Tags → New → tipe **GA4 Event**.
2. Configuration Tag: pilih `GA4 - Config` yang dibuat di langkah B.
3. Event Name: ketik `generate_lead`.
4. Event Parameters: tambahkan
   - `checkin_date` → Variable: `{{DLV - checkin_date}}`
   - `checkout_date` → Variable: `{{DLV - checkout_date}}`
   - `room_type` → Variable: `{{DLV - room_type}}`
5. Trigger: buat **Custom Event Trigger** baru, isi nama event `generate_lead`.
6. Untuk membuat variable `{{DLV - checkin_date}}`: Variables → New → tipe **Data Layer Variable** → Data Layer Variable Name: `checkin_date`.

Ulangi pola yang sama untuk event `cta_click` dan `scroll_50_percent`.

### D. Preview & Publish
1. Klik **Preview** di GTM → masukkan URL website kamu → tes semua interaksi (klik tombol, isi form).
2. Pastikan tag "fire" (menyala hijau) di panel Tag Assistant saat event terjadi.
3. Kalau semua benar → klik **Submit** → **Publish**.

### E. Verifikasi di GA4
1. Buka GA4 → **Reports** → **Realtime**.
2. Buka website kamu di tab lain, klik-klik tombol.
3. Event akan muncul di Realtime report dalam beberapa detik.

---

## 4. Setup Looker Studio Dashboard

Looker Studio itu alat gratis dari Google untuk bikin dashboard visual dari data GA4.

### Langkah:
1. Buka [lookerstudio.google.com](https://lookerstudio.google.com) → **Create** → **Report**.
2. Pilih connector **Google Analytics** → pilih properti GA4 kamu.
3. Looker akan otomatis generate dashboard dasar. Sekarang kustomisasi:

### Rekomendasi chart untuk website villa:

| Chart | Metric | Dimension |
|---|---|---|
| Scorecard | Total Users, Sessions, Engagement Rate | - |
| Time Series | Users per hari | Date |
| Bar Chart | Event Count | Event Name (`cta_click`, `generate_lead`, dll) |
| Table | Jumlah booking (event `generate_lead`) | `room_type` (parameter custom) |
| Pie Chart | Traffic Source | Session default channel group |
| Geo Map | Users by location | Country/City |

### Cara pakai custom parameter di Looker Studio:
1. GA4 custom parameter (`room_type`, dll) baru muncul di Looker Studio **setelah** kamu daftarkan sebagai **Custom Dimension** di GA4:
   - GA4 → Admin → **Custom Definitions** → **Create custom dimension**.
   - Dimension name: `Room Type`, Event parameter: `room_type`.
2. Tunggu 24-48 jam untuk data mulai masuk, baru bisa ditarik ke Looker Studio.

### Share dashboard
Klik **Share** di kanan atas → bisa share via link atau invite email, sama seperti Google Docs.

---

## 5. SEO — Yang Sudah Disiapkan di Kode

Buka `index.html`, semua ada di dalam `<head>`:

| Elemen | Fungsi | Lokasi di kode |
|---|---|---|
| `<title>` | Judul di hasil pencarian Google | Baris awal `<head>` |
| `meta description` | Deskripsi di bawah judul saat muncul di Google | Setelah `<title>` |
| `meta keywords` | Kata kunci (efeknya kecil sekarang, tapi baik untuk latihan) | - |
| `canonical` | Kasih tau Google URL "asli" halaman ini | - |
| Open Graph (`og:*`) | Tampilan saat link dibagikan di WhatsApp/Facebook | - |
| Twitter Card | Tampilan saat dibagikan di Twitter/X | - |
| Schema.org JSON-LD | Data terstruktur, biar Google paham ini bisnis "LodgingBusiness" (villa/hotel) | Blok `<script type="application/ld+json">` |

### Yang perlu kamu lakukan manual:

1. **Ganti semua placeholder** — URL `villaalangkayu.com`, nomor telepon, alamat, jadi milik kamu yang asli.
2. **Submit ke Google Search Console**:
   - Buka [search.google.com/search-console](https://search.google.com/search-console)
   - Tambahkan properti (domain kamu)
   - Verifikasi kepemilikan (biasanya lewat DNS record atau upload file HTML)
   - Submit `sitemap.xml` kamu di menu **Sitemaps**
3. **Gambar**: ganti URL Unsplash placeholder dengan foto villa asli, kompres ukurannya (pakai TinyPNG) supaya loading cepat — kecepatan loading itu faktor SEO.
4. **Alt text**: pastikan setiap `<img>` punya atribut `alt` yang deskriptif (sudah ada contohnya di kode) — ini juga bantu aksesibilitas.
5. **Local SEO**: daftarkan bisnis di **Google Business Profile** (business.google.com) — penting banget untuk pencarian "villa canggu near me".

---

## 6. Checklist Belajar (urutan yang disarankan)

- [ ] Buka `index.html` di browser, coba semua tombol & form
- [ ] Buat GTM Container, ganti `GTM-XXXXXXX`
- [ ] Buat GA4 Property, catat Measurement ID
- [ ] Buat tag GA4 Configuration di GTM
- [ ] Buat tag + trigger untuk event `generate_lead`
- [ ] Test pakai GTM Preview mode
- [ ] Publish GTM container
- [ ] Cek Realtime report di GA4
- [ ] Buat Custom Dimension untuk `room_type`
- [ ] Buat dashboard sederhana di Looker Studio
- [ ] Ganti semua meta tag SEO dengan data asli
- [ ] Submit sitemap ke Search Console

---

## Referensi Belajar Lanjutan
- Dokumentasi resmi GTM: `https://support.google.com/tagmanager`
- Dokumentasi resmi GA4: `https://support.google.com/analytics`
- Dokumentasi Looker Studio: `https://support.google.com/looker-studio`
